## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(MASS)
library(SimpleEnsembleGroup17)

## ----bagging, eval=FALSE------------------------------------------------------
#  bagging <- function(X, y, model_type = "lasso", R=42) {
#  ...
#  }

## ----load-data----------------------------------------------------------------
url <- "https://www.ams.sunysb.edu/~pfkuan/Teaching/AMS597/Data/leukemiaDataSet.txt"
data <- read.table(url, header = TRUE)
data$Group <- ifelse(data$Group=="AML",1,0)

## ----Bagging------------------------------------------------------------------
X <- data[, -which(names(data) == "Group")]
y <- data$Group
result<-bagging(X,y,model_type="lasso",R=42)
print(result$naive_importance)

