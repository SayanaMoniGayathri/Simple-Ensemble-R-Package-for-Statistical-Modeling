## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(MASS)
library(SimpleEnsembleGroup17)

## ----trainmodel, eval=FALSE---------------------------------------------------
#  trainmodel <- function(y, X, model_type = "random_forest", family = NULL, lambda = NULL) {
#  ...
#  }

## ----load-data----------------------------------------------------------------
data(Boston)
head(Boston)

## ----linear-regression--------------------------------------------------------
linear_model <- trainmodel(y = Boston$medv, X = Boston[, -which(names(Boston) == "medv")], model_type = "linear")
summary(linear_model)

## ----lasso-regression---------------------------------------------------------
lasso_model <- trainmodel(y = Boston$medv, X = Boston[, -which(names(Boston) == "medv")], model_type = "lasso")
coef(lasso_model)

## ----random-forest------------------------------------------------------------
rf_model <- trainmodel(y = Boston$medv, X = Boston[, -which(names(Boston) == "medv")], model_type = "random_forest")
importance(rf_model)

