## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(SimpleEnsembleGroup17)

## ----ensemble_prediction, eval=FALSE------------------------------------------
#  ensemble_prediction <- function(X, y, models, weights = NULL) {
#  
#  }

## ----load-data----------------------------------------------------------------
library(MASS)
data("Boston")

## -----------------------------------------------------------------------------
# Example usage
y <- Boston$medv
X <- Boston[, !names(Boston) %in% "medv"]
pred<-ensemble_prediction(X, y, models = c("linear", "lasso", "random_forest"))

